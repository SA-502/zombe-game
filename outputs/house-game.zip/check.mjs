import assert from 'node:assert/strict';
import fs from 'node:fs';
import {SPAWN,blocked,move,floorAt,roomAt} from './dist/physics.mjs';
const asset=JSON.parse(fs.readFileSync(new URL('./dist/assets/house.json',import.meta.url)));
const c=asset.colliders;
assert(!blocked(SPAWN.x,SPAWN.z,c),'Spawn must be free');
let p={...SPAWN};move(p,0,-2.3,c);assert(p.z < -1.8,'Player can pass through the rear doorway');
p={x:.5,z:0};move(p,3,0,c);assert(p.x<.7,'Kitchen wall blocks movement');
p={x:0,z:5};move(p,3,0,c);assert(p.x>2.9,'Kitchen doorway is passable');
p={x:-2.2,z:3};move(p,0,2,c);assert(p.z>4.9,'Bedroom doorway is passable');
p={x:-2,z:0};move(p,-10,0,c);assert(p.x>-5.65,'Cannot cross exterior wall even at high speed');
p={x:7,z:0};move(p,0,-100,c);assert(p.z>-14.5,'Cannot leave plot');
assert.equal(roomAt(-2,5),'غرفة النوم');assert.equal(roomAt(3,0),'المطبخ');assert.equal(roomAt(-2,-7),'الفناء الخلفي');
assert.equal(floorAt(-2,0),.584);assert.equal(floorAt(-2,-7),.225);
for(const item of [...asset.objects,...asset.player]){assert(item.positions.every(Number.isFinite));assert.equal(item.positions.length,item.normals.length);assert(asset.materials[item.material]);}
console.log('PASS: spawn, exterior walls, kitchen wall, both interior doorways, garden access, bounds, floor levels, room labels and all exported meshes.');
